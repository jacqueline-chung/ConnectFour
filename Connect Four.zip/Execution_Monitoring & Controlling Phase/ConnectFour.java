/**
 * Auto Generated Java Class.
 */
public class ConnectFour {
  
  public ConnectFour() { 
    /* YOUR CONSTRUCTOR CODE HERE*/
  }
  
  public static void main(String[] args) { 
    
  }
  
  /* ADD YOUR CODE HERE */
  
}
