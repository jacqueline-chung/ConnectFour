//  public static int[] score(int player, int[][] grid, int depth){
//    int[] value=new int[2];
//    
//    if(depth==0){
//      int winner=gridcheck(grid);              //looks at the whole board and returns who wins
//      if(winner==3){
//        value[1]=1000;                        //if AI wins value is 1000
//      }else if(winner==1){
//        value[1]=-1000;                        //if player wins value is -1000
//      }else{                  
//        value[1]=0;                            //if no one wins value is 0
//      }
//      return value;
//    }
//    
//    int best[]=new int[2];                  //best[0] is the best column, best[1] is the value given to that column
//    
//    if(player==3){                         //if it is the AI's turn:
//      best[1]=-1000;
//      for(int i=0;i<7;i++){
//        int[][] newgrid=new int[6][7];
//        for(int j = 0; j < 6; j++){
//          newgrid[j] = grid[j].clone();            //copy the array to a new array
//        }
//        
//        int dropheight=drop(i,player,newgrid);     //drop the piece into the new array - return -1 if full
//        if(dropheight!=-1){
//          value=score(1,newgrid,depth-1);     //run method on other player at 1 less depth
//        }else{
//          value[1]=-1001;
//        }
//        
//        if(depth==totaldepth){
//          System.out.println(value[1]);
//        }
//        if(best[1]<=value[1]){                    //find best column for AI
//          best[1]=value[1];
//          best[0]=i;
//        }
//        
//      }
//      
//    }
//    
//    if(player==1){
//      best[1]=1000;
//      for(int i=0;i<7;i++){
//        int[][] newgrid=new int[6][7];
//        for(int j = 0; j < 6; j++){
//          newgrid[j] = grid[j].clone();            //copy the array to a new array
//        }
//        
//        int dropheight=drop(i,player,newgrid);      //same stuff as other part
//        if(dropheight!=-1){
//          value=score(3,newgrid,depth-1);
//        }else{
//          value[1]=1001;
//        }
//
//        if(best[1]>value[1]){                      //find worst value for you
//          best[1]=value[1];
//          best[0]=i;
//        }
//        
//      }
//      
//    }
//    return best;
//    
//  }
  