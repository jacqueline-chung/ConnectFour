import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class connectFour {
 JFrame frame;
 JPanel panel;
 final int rowTiles = 6;
 final int colTiles = 7;
 static int[][] grid = new int[6][7];
 int row, col, rowSelected, colSelected = 0;
 int pTurn = 0;
 boolean win = false;
 JButton[][] button = new JButton[rowTiles][colTiles];
 JButton clear;
 JLabel whoWon;
 GridLayout myGrid = new GridLayout(7,7);
 //recommended image size is 100 by 100 pixels
 final ImageIcon c0 = new ImageIcon("p0.png");
 final ImageIcon c1 = new ImageIcon("p1.png");
 final ImageIcon c2 = new ImageIcon("p2.png");

 public connectFour() {
  frame = new JFrame("Connect Four");
  frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  panel = new JPanel();
  panel.setLayout(myGrid);
  whoWon = new JLabel("");
  clear = new JButton("Clear");
  clear.addActionListener(new clearListener());
  clear.setPreferredSize(new Dimension(10,10));

  //-1 are empty slots not allowed to go in (nothing is under them)
  //0 are empty slots allowed to fill, either bottom most or already a piece under them
  //1 for player1, 2 for player2
  for (int x = rowTiles - 2; x >= 0; x--) {
   for (int y = colTiles - 1; y >= 0; y--) {
    grid[x][y] = -1;
   }
  }

  for (row = 0; row <= rowTiles - 1; row++) {
   for (col = 0; col <= colTiles - 1; col++) {
    button[row][col] = new JButton(c0);
    button[row][col].addActionListener(new buttonListener());
    panel.add(button[row][col]);
   }
  }

  panel.add(whoWon);
  panel.add(clear);
  frame.setContentPane(panel);
  frame.pack();
  frame.setVisible(true);
 }

 class buttonListener implements ActionListener {
  public void actionPerformed(ActionEvent event) {
   for (row = rowTiles-1; row >= 0; row--) {
    for (col = colTiles-1; col >= 0; col--) {
     if (button[row][col] == event.getSource()) {
      if (pTurn % 2 == 0 && grid[row][col] == 0) {
       button[row][col].setIcon(c1);
       grid[row][col] = 1;
       try {
        grid[row-1][col] = 0;
       }
       catch (ArrayIndexOutOfBoundsException e) {
        System.out.println("Reached top of column");
       }
       if (checkWin()) {
        System.out.println("player 1 win");
        whoWon.setText("Player 1 wins");
        for (int x = rowTiles - 1; x >=0; x--) {
         for (int y = colTiles - 1; y >= 0; y--) {
          grid[x][y] = -1;
         }
        }
       }
       pTurn = pTurn + 1;
       break;
      }
      if (pTurn % 2 == 1 && grid[row][col] == 0) {
       button[row][col].setIcon(c2);
       grid[row][col] = 2;
       try {
        grid[row-1][col] = 0;
       }
       catch (ArrayIndexOutOfBoundsException e) {
        System.out.println("Reached top of column");
       }
       if (checkWin()) {
        System.out.println("player 2 win");
        whoWon.setText("Player 2 wins");
        for (int x = rowTiles - 1; x >=0; x--) {
         for (int y = colTiles - 1; y >= 0; y--) {
          grid[x][y] = -1;
         }
        }
       }
       pTurn = pTurn + 1;
       break;
      }
      else {
       System.out.println(":)/>");//poker face
      }
     }
    }
   }
  }
 }

 class clearListener implements ActionListener {
  public void actionPerformed(ActionEvent event) {
   for (int x = rowTiles - 1; x >= 0; x--) {
    for (int y = colTiles - 1; y >= 0; y--) {
     grid[x][y] = -1;
     button[x][y].setIcon(c0);
    }
   }
   for (int y = colTiles - 1; y >= 0; y--) {
    grid[5][y] = 0;
   }
   whoWon.setText("");
  }
 }

 public boolean checkWin() {
  // check for a horizontal win
  for (int x=0; x<6; x++) {
   for (int y=0; y<4; y++) {
    if (grid[x][y] != 0 && grid[x][y] != -1 &&
    grid[x][y] == grid[x][y+1] &&
    grid[x][y] == grid[x][y+2] &&
    grid[x][y] == grid[x][y+3]) {
     win = true;
    }
   }
  }
  // check for a vertical win
  for (int x=0; x<3; x++) {
   for (int y=0; y<7; y++) {
    if (grid[x][y] != 0 && grid[x][y] != -1 &&
    grid[x][y] == grid[x+1][y] &&
    grid[x][y] == grid[x+2][y] &&
    grid[x][y] == grid[x+3][y]) {
     win = true;
    }
   }
  }
  // check for a diagonal win (positive slope)
  for (int x=0; x<3; x++) {
   for (int y=0; y<4; y++) {
    if (grid[x][y] != 0 && grid[x][y] != -1 &&
    grid[x][y] == grid[x+1][y+1] &&
    grid[x][y] == grid[x+2][y+2] &&
    grid[x][y] == grid[x+3][y+3]) {
     win = true;
    }
   }
  }
  // check for a diagonal win (negative slope)
  for (int x=3; x<6; x++) {
   for (int y=0; y<4; y++) {
   if (grid[x][y] != 0 && grid[x][y] != -1 &&
    grid[x][y] == grid[x-1][y+1] &&
    grid[x][y] == grid[x-2][y+2] &&
    grid[x][y] == grid[x-3][y+3]) {
     win = true;
    }
   }
  }
  return win;
 }

 public static void main(String[] args) {
  javax.swing.SwingUtilities.invokeLater(new Runnable() {
   public void run() {
    JFrame.setDefaultLookAndFeelDecorated(true);
    new connectFour();
   }
  });
 }
}

/* Hey Mr. Qayum, you know that I'm not good at software stuff, but if that stuff last week didn't happen, I don't think I would have had the motivation to pull this off.
 *It doesn't look pretty, but works nicely. Thanks for everything this year, see you in september =)
 *
 *David Tan
 *
 *Brian Wong worked unbelievably hard one-man army'ing Part A, props to him.
 */