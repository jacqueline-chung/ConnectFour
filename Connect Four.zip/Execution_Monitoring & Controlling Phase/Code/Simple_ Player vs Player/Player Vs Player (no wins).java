import java.util.Scanner;

public class Connect4Simple{
  
  final static int WIDTH = 6;//global variable
  final static int HEIGHT = 7;//global variable
  final static int BOTTOM_ROW = WIDTH - 1;//global variable
  
  //game board
  static String[][] board = new String[WIDTH][HEIGHT];
  
  //creates userInput
  static Scanner userInput = new Scanner(System.in);//scanner
  
  public static void main(String[] args){//main method
    CreateBoard();//method to CREATE the board
    DisplayBoard();//method to DISPLAY the board
    boolean flag = true;//checks if player has went
    System.out.println("Player R goes first");
    System.out.println("Player Y goes Second");
    System.out.println("Use 0-6 to choose what column you want to place your move in");
  
    
    while(flag){
      //activates player 1s turn, then prints board
      DropR();
      DisplayBoard();
      
      //activates player 2s turn, then prints board
      DropY();
      DisplayBoard();
    }
  }
  
  
  
  public static void CreateBoard() {
    for (int width = 0; WIDTH > width; width += 1) {
      for (int height = 0; HEIGHT > height; height += 1) {
        board[width][height] = " O ";
      }
    }
  }
  public static void DisplayBoard() {
    //prints the board
    for (int width = 0; WIDTH > width; width += 1) {
      for (int height = 0; HEIGHT > height; height += 1) {
        System.out.print(board[width][height]);
      }System.out.println();
    }System.out.println();
  }
  
  public static void DropR(){
    //creates a counter
    int counter = 1;
    
    //shows whos turn
    System.out.println("Player 1 turn");
    
    //gets input
    int column = userInput.nextInt();
    
    while(true){
      if(column > WIDTH || column < WIDTH ){
        System.out.println("INVALID MOVE");
        DropR();
        //break;
      }
      
      if (board[BOTTOM_ROW][column] == " O ") { //checks to see if space is blank, puts X there if it is
        board[BOTTOM_ROW][column] = " R ";
        //break; //breaks loop after placing
      }else if(board[BOTTOM_ROW][column] == " R " || board[BOTTOM_ROW][column] == " Y "){ //if space isn't blank, checks to see if one above is
        if(board[BOTTOM_ROW - counter][column] == " O "){ //puts X if blank
          board[BOTTOM_ROW - counter][column] = " R ";
          //break; //breaks loop after placing
        }
      }
      counter += 1; //adds one to counter if the space wasn't blank, then loops again
      if(counter == WIDTH){ //checks to see if at end of column
        System.out.println("That column is full");
        break;
      }
    }
  }
  
  
  public static void DropY(){
    //creates a counter
    int counter = 1;
    
    //shows whos turn
    System.out.println("Player 2 turn");
    
    //gets input
    int column = userInput.nextInt();
    
    while(true){
      if(column > WIDTH|| column < WIDTH ){
        System.out.println("INVALID MOVE");
        DropY();
        //break;
      }
      
      if (board[BOTTOM_ROW][column] == " O ") { //checks to see if space is blank, puts O there if it is
        board[BOTTOM_ROW][column] = " Y ";
        break; //breaks loop after placing
      }else if(board[BOTTOM_ROW][column] == " R " || board[BOTTOM_ROW][column] == " O "){ //if space isn't blank, checks to see if one above is
        if(board[BOTTOM_ROW - counter][column] == " O "){ //puts O if blank
          board[BOTTOM_ROW - counter][column] = " Y ";
          break; //breaks loop after placing
        }
      }
      counter += 1; //adds one to counter if the space wasn't blank, then loops again
      if(counter == WIDTH){ //checks to see if at end of column
        System.out.println("That column is full");
        break;
      }
    }
  }
  
}