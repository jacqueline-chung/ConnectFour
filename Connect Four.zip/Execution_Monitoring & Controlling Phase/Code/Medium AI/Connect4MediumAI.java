//imports
import java.util.Scanner;
import java.util.Random;

public class Connect4MediumAI_Jacqueline{
  //global variables
  final static int HEIGHT = 6;
  final static int WIDTH = 7;
  final static int BOTTOM_ROW = HEIGHT - 1;
  static String[][] board = new String[HEIGHT][WIDTH];//game board
  static Scanner userInput = new Scanner(System.in);//scanner
  
  public static void main(String[] args){//main method
    int userChoice;//user chooses option from menu
//    System.out.println("Menu: \n 1.) Player vs Player \n 2.) Simple AI \n 3.) Medium AI \n 2.) Hard AI");//menu
//    userChoice = userInput.nextInt();//get user input
//    
//    if (userChoice==1){//first choice PLAYER VS PLAYER
//      System.out.println("PLAYER vs PLAYER");
//      CreateBoard();//call create the board method
//      System.out.println("Player R goes first");
//      System.out.println("Use 0-6 to choose what column you want");
//      DisplayBoard();//display board
//      boolean flag = true;//creates boolean to determine status of game 
//      
//      
//      while(flag){
//        DropR();//activates player 1s turn, then prints board
//        DisplayBoard();//display board 
//        if(!CheckR()){//determines if player 1 has won after that turn
//          flag = false; //sets flag to false so loop is not repeated if player 1 won
//          break; //break to skip player 2s turn if won
//        } 
//        DropY();//activates player 2s turn, then displays board
//        DisplayBoard();
//        if(!CheckY()){//determines if player 1 has won after that turn
//          flag = false; //sets flag to false so loop is not repeated if player 2 won
//          break; // break for consistency
//        }
//      }
//      
//    } else if (userChoice == 2) {//first choice SIMPLE AI vs PLAYER  
//      
//      CreateBoard(); //creates board
//      System.out.println("SIMPLE AI vs PLAYER"); //output message
//      DisplayBoard();//display board
//      boolean flag = true;//creates boolean to determine status of game   
//      boolean AIturn=false; //creates boolean to determine if it's AI's turn
//      
//      while(flag){
//        AIturnSIMPLE();//activates AI turn, then prints board
//        DisplayBoard(); //display board   
//        if(!CheckR()){//determines if AI has won after that turn
//          AIturn=true;
//          flag = false; //sets flag to false so loop is not repeated if player 1 won
//          break; //break to skip player 2s turn if won
//        } 
//        DropY();//activates player's turn, then prints board
//        DisplayBoard();
//        if(!CheckY()){ //determines if player has won after that turn
//          flag = false; //sets flag to false so loop is not repeated if player 2 won
//          break; // break for consistency
//        }
//      }
//      
//    } else if (userChoice == 3) { //first choice MEDIUM AI vs PLAYER
    
    CreateBoard(); //create board
    System.out.println("MEDIUM AI vs PLAYER"); //output message
    
    DisplayBoard();//display board
    
    boolean flag = true;//creates boolean to determine status of game   
    boolean AIturn = false; //creates boolean to determine if it's AI's turn
    
    while(flag){
      
      DropR();//activates player's turn, then prints board
      DisplayBoard(); //displays board   
      
      if(!CheckR()){//determines if AI has won after that turn
        //AIturn=true;
        flag = false; //sets flag to false so loop is not repeated if player 1 won
        break; //break to skip player 2s turn if won
      } 
      
      AIturnMEDIUM();//activates player's turn, then prints board
      DisplayBoard(); //display board
      
      if(!CheckY()){ //determines if player has won after that turn
        flag = false; //sets flag to false so loop is not repeated if player 2 won
        break; // break for consistency
      }
    }
    //}
    
  }
  
  
////////////////////////////////////////*********CREATE BOARD**********\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\    
  public static void CreateBoard() {
    //fills board with "O" for the height and width
    for (int height = 0; HEIGHT > height; height += 1) {
      for (int width = 0; WIDTH > width; width += 1) {
        board[height][width] = "O";
      }
    }
  }
  
////////////////////////////////////////*********DISPLAY BOARD**********\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\     
  public static void DisplayBoard() {
    //prints the board
    for (int height = 0; HEIGHT > height; height += 1) {
      for (int width = 0; WIDTH > width; width += 1) {
        System.out.print(board[height][width]);
      }
      System.out.println();
    }
    System.out.println();
  }
////////////////////////////////////////*********DROP RED CHIP**********\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\     
  public static void DropR(){
    //creates a counter
    int counter = 1;
    
    //shows whos turn
    System.out.println("Player 1 turn");
    
    //gets input
    int column = userInput.nextInt();
    
    while(true){
      if(column > HEIGHT){
        System.out.println("That's not a valid column");
        break;
      }
      
      if (board[BOTTOM_ROW][column] == "O") { //checks to see if space is blank, puts R there if it is
        board[BOTTOM_ROW][column] = "R";
        break; //breaks loop after placing
      }else if(board[BOTTOM_ROW][column] == "R" || board[BOTTOM_ROW][column] == "Y"){ //if space isn"t blank, checks to see if one above is
        if(board[BOTTOM_ROW - counter][column] == "O"){ //puts R if blank
          board[BOTTOM_ROW - counter][column] = "R";
          break; //breaks loop after placing
        }
      }
      counter += 1; //adds one to counter if the space wasn't blank, then loops again
      if(counter == HEIGHT){ //checks to see if at end of column
        System.out.println("That column is full");
        break;
      }
    }
  }
  
////////////////////////////////////////*********DROP YELLOW CHIP**********\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\     
  public static void DropY(){
    //creates a counter
    int counter = 1;
    
    //shows whos turn
    System.out.println("Player 2 turn");
    
    //gets input
    int column = userInput.nextInt();
    
    while(true){
      if(column > HEIGHT){
        System.out.println("That's not a valid column");
        break;
      }
      
      if (board[BOTTOM_ROW][column] == "O") { //checks to see if space is blank, puts Y there if it is
        board[BOTTOM_ROW][column] = "Y";
        break; //breaks loop after placing
      }else if(board[BOTTOM_ROW][column] == "R" || board[BOTTOM_ROW][column] == "Y"){ //if space isn't blank, checks to see if one above is
        if(board[BOTTOM_ROW - counter][column] == "O"){ //puts Y if blank
          board[BOTTOM_ROW - counter][column] = "Y";
          break; //breaks loop after placing
        }
      }
      counter += 1; //adds one to counter if the space wasn't blank, then loops again
      if(counter == HEIGHT){ //checks to see if at end of column
        System.out.println("That column is full");
        break;
      }
    }
  }
  
  ////////////////////////////////////////*********SIMPLE (random) AI2**********\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\     
  public static void AIturnSIMPLE2(){
    //creates a counter
    int counter = 1;
    
    //shows whos turn
    //System.out.println("AI");
    
    //gets input
    Random randomGenerator = new Random();
    int column = randomGenerator.nextInt(6) + 0;
    boolean bounds;
    
    System.out.println("Column: " +  column); //test in console
    System.out.println("Counter Y: " +  counter); //test in console
    
    while(true){
      if (board[BOTTOM_ROW][column] == "O") { //checks to see if space is blank, puts Y there if it is
        board[BOTTOM_ROW][column] = "Y"; 
        break; //breaks loop after placing
      } else if(board[BOTTOM_ROW][column] == "R" || board[BOTTOM_ROW][column] == "Y"){ //if space isn't blank, checks to see if one above is
        if(board[BOTTOM_ROW - counter][column] == "O"){ //puts Y if blank
          board[BOTTOM_ROW - counter][column] = "Y";
          break; //breaks loop after placing
        }
      }
      
      counter ++; //adds one to counter if the space wasn't blank, then loops again
      
      System.out.println("Counter Y: " +  counter); //test in console
      
      do {
        bounds = false;//everytime the do while loop loops, set the bounds variable to false
        
        //if one of the item in the array is the same as the one the user just entered
        if(counter == HEIGHT){ //checks to see if at end of column
          bounds = true;//set the bounds variable to be true
          column = randomGenerator.nextInt(6) + 0;//stores the new number user entered in the same spot in the array            
          
          System.out.println("NEW Column: " +  column); //test in console
          //break;//exit the for loop for checking for out of bounds, so that the next time it checks, it starts from the beginning of the array
        }
      } while (!bounds);//
      
//      if(counter == HEIGHT){ //checks to see if at end of column
//        System.out.println("That  column " + column + " is full");
//        //AIturnSIMPLE2(); //recursively call it to repeat it until it picks another available column
//        break;
//      }
      
      //counter += 1; //adds one to counter if the space wasn't blank, then loops again
    }
  }
  
////////////////////////////////////////*********CHECK HORIZONTAL (RED)**********\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\     
  public static boolean CheckRHorizontal(){
    //creates boolean to act as flag
    boolean flag = true;
    
    //creates counter
    int counter = 0;
    while(flag){
      
      //goes through board horizontally
      for(int height = 0; HEIGHT > height; height += 1){
        for(int width = 0; WIDTH > width; width += 1){
          if(board[height][width] == "R"){ //if it finds an R, add 1 to counter
            counter += 1;
          }else{
            counter = 0; // if next piece is not an R, set counter to 0
          }
          if(counter >= 4){
            System.out.println("Player 1 wins"); //if counter is greater or equal to 4, player wins
            flag = false;
          }
        }
      }
      break;
    }
    return flag;
  }
////////////////////////////////////////*********CHECK VERTICAL (RED)**********\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\     
  public static boolean CheckRVertical(){
    //creates boolean to act as flag
    boolean flag = true;
    
    //creates counter
    int counter = 0;
    while(flag){
      
      //goes through board vertically
      for(int width = 0; WIDTH > width; width += 1){
        for(int height = 0; HEIGHT > height; height += 1){
          if(board[height][width] == "R"){ //if it finds an R, add 1 to counter
            counter += 1;
          }else{
            counter = 0; // if next piece is not an R, set counter to 0
          }
          if(counter >= 4){
            System.out.println("Player 1 wins"); //if counter is greater or equal to 4, player wins
            flag = false;
          }
        }
      }
      break;
    }
    return flag;
  }
  
////////////////////////////////////////*********CHECK VERTICAL (YELLOW)**********\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\     
  public static boolean CheckYVertical(){
    //creates boolean to act as flag
    boolean flag = true;
    
    //creates counter
    int counter = 0;
    
    while(flag){
      
      //goes through board vertically
      for(int width = 0; WIDTH > width; width += 1){
        for(int height = 0; HEIGHT > height; height += 1){
          if(board[height][width] == "Y"){ //if it finds an Y, add 1 to counter
            counter += 1;
          } else {
            counter = 0; // if next piece is not an Y, set counter to 0
          }
          if(counter >= 4){
            System.out.println("Player 2 wins"); //if counter is greater or equal to 4, player wins
            flag = false;
          }
        }
      }
      break;
    }
    return flag;
  }
  
////////////////////////////////////////*********CHECK HORIZONTAL (YELLOW)**********\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\ 
  public static boolean CheckYHorizontal(){
    //creates boolean to act as flag
    boolean flag = true;
    
    //creates counter
    int counter = 0;
    while(flag){
      
      //goes through board vertically
      for(int height = 0; HEIGHT > height; height += 1){
        for(int width = 0; WIDTH > width; width += 1){
          if(board[height][width] == "Y"){ //if it finds an Y, add 1 to counter
            counter += 1;
          }else{
            counter = 0; // if next piece is not an Y, set counter to 0
          }
          if(counter >= 4){
            System.out.println("Player 2 wins"); //if counter is greater or equal to 4, player wins
            flag = false;
          }
        }
      }
      break;
    }
    return flag;
  }
////////////////////////////////////////*********CHECK DIAGONAL (RED forward)**********\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\     
  public static boolean CheckRDiagonalForward(){
    //flag
    boolean flag = true;
    
    //counter
    int counter = 0;
    
    //check boolean
    Boolean check = false;
    
    //checkers
    int checkColumn = 1;
    int checkRow = 1;
    
    while(flag){ //goes through until an R is found
      for(int height = 0; HEIGHT > height; height += 1){
        for(int width = 0; WIDTH > width; width += 1){
          if(board[height][width] == "R"){ //if R is found, add one to counter and go into loop
            counter += 1;
            check = true;
            while(check){ //goes through diagonally looking for Rs
              if(checkColumn + height <= HEIGHT - 1&& checkRow + width <= WIDTH - 1){
                if(board[height + checkColumn][width + checkRow] == "R"){ //if R is found, add 1 to counter
                  counter += 1;
                }
              }
              
              //adds 1 to checkers
              checkColumn += 1;
              checkRow += 1;
              
              if(checkColumn == HEIGHT -1 || checkRow == WIDTH -1){ //if outside of board, break
                check = false;
                break;
              }
              
              if(counter >= 4){
                System.out.println("Player 1 wins"); //if counter is greater or equal to 4, player wins
                check = false;
                flag = false;
                break;
              }
            }
          }
          if(counter >= 4){
            flag = false;
            break;
          }
          
          //resets counter and checkers
          counter = 0;
          checkColumn = 1;
          checkRow = 1;
        }
      }
      break;
    }
    return flag;
  }
  
  ////////////////////////////////////////*********CHECK DIAGONAL (YELLOW forward)**********\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\ 
  public static boolean CheckYDiagonalForward(){
    //flag
    boolean flag = true;
    
    //counter
    int counter = 0;
    
    //check boolean
    Boolean check = false;
    
    //checkers
    int checkColumn = 1;
    int checkRow = 1;
    
    while(flag){ //goes through until an Y is found
      for(int height = 0; HEIGHT > height; height += 1){
        for(int width = 0; WIDTH > width; width += 1){
          if(board[height][width] == "Y"){ //if Y is found, add one to counter and go into loop
            counter += 1;
            check = true;
            while(check){ //goes through diagonally looking for Os
              if(checkColumn + height <= HEIGHT - 1&& checkRow + width <= WIDTH - 1){
                if(board[height + checkColumn][width + checkRow] == "Y"){ //if Y is found, add 1 to counter
                  counter += 1;
                }
              }
              
              //adds 1 to checkers
              checkColumn += 1;
              checkRow += 1;
              
              if(checkColumn == HEIGHT -1 || checkRow == WIDTH -1){ //if outside of board, break
                check = false;
                break;
              }
              
              if(counter >= 4){
                System.out.println("Player 2 wins"); //if counter is greater or equal to 4, player wins
                check = false;
                flag = false;
                break;
              }
            }
          }
          if(counter >= 4){
            flag = false;
            break;
          }
          
          //resets counter and checkers
          counter = 0;
          checkColumn = 1;
          checkRow = 1;
        }
      }
      break;
    }
    return flag;
  }
  
////////////////////////////////////////*********CHECK DIAGONAL (RED back)**********\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
  public static boolean CheckRDiagonalBack(){
    //flag
    boolean flag = true;
    
    //counter
    int counter = 0;
    
    //check boolean
    Boolean check = false;
    
    //checkers
    int checkColumn = 1;
    int checkRow = 1;
    
    while(flag){ //goes through until an R is found
      for(int height = 0; HEIGHT > height; height += 1){
        for(int width = 0; WIDTH > width; width += 1){
          if(board[height][width] == "R"){ //if R is found, add one to counter and go into loop
            counter += 1;
            check = true;
            while(check){ //goes through diagonally looking for Rs
              if(height - checkColumn >= 0 && width - checkRow >= 0){
                if(board[height - checkColumn][width - checkRow] == "R"){
                  counter += 1; //if R is found, add 1 to counter
                }
              }
              
              //adds 1 to checkers
              checkColumn += 1;
              checkRow += 1;
              
              if(checkColumn == 0 || checkRow == WIDTH -1){ //if outside of board, break
                check = false;
                break;
              }
              
              if(counter >= 4){
                System.out.println("Player 1 wins"); //if counter is greater or equal to 4, player wins
                check = false;
                flag = false;
                break;
              }
            }
          }
          if(counter >= 4){
            flag = false;
            break;
          }
          
          //resets counter and checkers
          counter = 0;
          checkColumn = 1;
          checkRow = 1;
        }
      }
      break;
    }
    return flag;
  }
  
////////////////////////////////////////*********CHECK DIAGONAL (YELLOW back)**********\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\    
  public static boolean CheckYDiagonalBack(){
    //flag
    boolean flag = true;
    
    //counter
    int counter = 0;
    
    //check boolean
    Boolean check = false;
    
    //checkers
    int checkColumn = 1;
    int checkRow = 1;
    
    while(flag){
      
      //goes through until an Y is found
      for(int height = 0; HEIGHT > height; height += 1){
        for(int width = 0; WIDTH > width; width += 1){
          if(board[height][width] == "Y"){ //if Y is found, add one to counter and go into loop
            counter += 1;
            check = true;
            while(check){ //goes through diagonally looking for Os
              if(height - checkColumn >= 0 && width - checkRow >= 0){
                if(board[height - checkColumn][width - checkRow] == "Y"){
                  counter += 1; //if Y is found, add 1 to counter
                }
              }
              
              //adds 1 to checkers
              checkColumn += 1;
              checkRow += 1;
              
              if(checkColumn == 0 || checkRow == WIDTH -1){ //if outside of board, break
                check = false;
                break;
              }
              
              if(counter >= 4){
                System.out.println("Player 2 wins"); //if counter is greater or equal to 4, player wins
                check = false;
                flag = false;
                break;
              }
            }
          }
          if(counter >= 4){
            flag = false;
            break;
          }
          
          //resets counter and checkers
          counter = 0;
          checkColumn = 1;
          checkRow = 1;
        }
      }
      break;
    }
    return flag;
  }
  
  
  ////////////////////////////////////////*********MEDIUM AI**********\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\     
  public static void AIturnMEDIUM(){

    boolean almostWin1 = false, almostWin2 = false, almostWin3 = false, almostWin4 = false;
    
    ///////////////check in all directions for potential winnings with opponent before randomizing
    int counter = 0;
    
    for(int row = 5; row >= 0; row--){
      for(int col = 0; col <= 6; col++){
        
        if(board[row][col] == "O") continue;
        
        //Checking cells to the right
        if (col <= 3){
          for(int k = 0; k < 4; k++){ 
            if(board[row][col + k] == "R") {
              counter++;
            } else {
              break; 
            }
            
            if (counter == 3){
              System.out.println("R can win...!"); //test in console
              almostWin1 = true;
              //if (col < 6) {
                board[row][col + 3] = "Y";
                break;
              //}
            } 
            
            counter = 0;
          } 
          
          //Checking cells up
          if (row >= 3){
            for(int k = 0; k < 4;k++){
              if (board[row - k][col] == "R") {
                counter++;
              } else {
                break;
              }
            }
            
            if (counter == 3) {
              System.out.println("R can win...!"); //test in console
              almostWin2 = true;
              //if (row < 5) {
                board[row - 4][col] = "Y";
                break;
              //}
            } 
            
            counter = 0;
          } 
          
          //Checking diagonal up-right
          if(col <= 3 && row >= 3){
            for(int k = 0; k < 4;k++){
              if(board[row - k][col + k] == "R") {
                counter++;
              } else {
                break;
              }
            }
            
            if (counter == 3) {
              System.out.println("R can win...!"); //test in console
              almostWin3 = true;
              //if (col > 0 && row < 5) {
                board[row - 4][col + 3] = "Y";
                break;
              //} 
            } 
            
            counter = 0;
          }
          
          //Checking diagonal up-left
          if(col >= 3 && row >= 3){
            for(int k = 0;k < 4;k++){
              if(board[row - k][col - k] == "R") {
                counter++;
              } else {
                break;
              }
            } 
            
            if (counter == 3) {
              System.out.println("R can win...!"); //test in console
              almostWin4 = true;
             // if (col < 6 && row < 5) {
                board[row - 4][col - 3] = "Y";
                break;
              //}
            } 
            
            counter = 0;
          }
        }
      }
      break;
    }

    if (almostWin1 == false && almostWin2 == false && almostWin2 == false && almostWin2 == false) {
      randomAIMedium();
    }
    
    //gameResultsMedium(); //call game result for medium AI
    
//    Check_AI_medium_Horizontal();
//    Check_AI_medium_Vertical();
    // Check_AI_medium_DiagonalForward();
    // Check_AI_medium_DiagonalBack()
    
  }
  
  public static void randomAIMedium () {
    
    int marker = 1;
    Random randomGenerator = new Random();
    int column = randomGenerator.nextInt(6) + 0;
    
    System.out.println("Random Column: " +  column); //test in console
    
    while(true){
      if (board[BOTTOM_ROW][column] == "O") { //checks to see if space is blank, puts X there if it is
        board[BOTTOM_ROW][column] = "Y";
        break; //breaks loop after placing
      } else if(board[BOTTOM_ROW][column] == "R" || board[BOTTOM_ROW][6] == "Y"){ //if space isn't blank, checks to see if one above is
        if(board[BOTTOM_ROW - marker][column] == "O"){ //puts X if blank
          board[BOTTOM_ROW - marker][column] = "Y";
          break; //breaks loop after placing
        }
      }
      marker ++; //adds one to counter if the space wasn't blank, then loops again
      
      System.out.println("Marker Y: " +  marker); //test in console
      
      System.out.println("Yellow(AI) added");
      
      if(marker == HEIGHT){ //checks to see if at end of column
        System.out.println("That column is full");
        break;
      }
    }
  }
  
//  
//   public boolean checkWin() {
//  // check for a horizontal win
//  for (int x=0; x<6; x++) {
//   for (int y=0; y<4; y++) {
//    if (grid[x][y] != 0 && grid[x][y] != -1 &&
//    grid[x][y] == grid[x][y+1] &&
//    grid[x][y] == grid[x][y+2] &&
//    grid[x][y] == grid[x][y+3]) {
//     win = true;
//    }
//   }
//  }
//  // check for a vertical win
//  for (int x=0; x<3; x++) {
//   for (int y=0; y<7; y++) {
//    if (grid[x][y] != 0 && grid[x][y] != -1 &&
//    grid[x][y] == grid[x+1][y] &&
//    grid[x][y] == grid[x+2][y] &&
//    grid[x][y] == grid[x+3][y]) {
//     win = true;
//    }
//   }
//  }
//  // check for a diagonal win (positive slope)
//  for (int x=0; x<3; x++) {
//   for (int y=0; y<4; y++) {
//    if (grid[x][y] != 0 && grid[x][y] != -1 &&
//    grid[x][y] == grid[x+1][y+1] &&
//    grid[x][y] == grid[x+2][y+2] &&
//    grid[x][y] == grid[x+3][y+3]) {
//     win = true;
//    }
//   }
//  }
//  // check for a diagonal win (negative slope)
//  for (int x=3; x<6; x++) {
//   for (int y=0; y<4; y++) {
//   if (grid[x][y] != 0 && grid[x][y] != -1 &&
//    grid[x][y] == grid[x-1][y+1] &&
//    grid[x][y] == grid[x-2][y+2] &&
//    grid[x][y] == grid[x-3][y+3]) {
//     win = true;
//    }
//   }
//  }
//  return win;
// }
  
  
  ////////////////GAME RESUTS FOR MEDIUM AI////////////////
//  public static int gameResultsMedium() {
//    int AIScore = 0, pScore = 0;
//    
//    for(int i = 5; i >= 0; i--){
//      for(int j = 0; j <= 6; j++){
//        
//        if(board[i][j] == "O") continue;
//        
//        //Checking cells to the right
//        if (j <= 3){
//          for(int k = 0; k < 4; k++){ 
//            if(board[i][j+k] == "R") {
//              AIScore++;
//            } else if(board[i][j + k] == "Y") {
//              pScore++;
//            } else {
//              break; 
//            }
//            if(AIScore == 4){
//              return 1; 
//            } else if (pScore == 4) {
//              return 2;
//            }
//            AIScore = 0; 
//            pScore = 0;
//          } 
//          
//          //Checking cells up
//          if (i >= 3){
//            for(int k = 0; k < 4;k++){
//              if (board[i - k][j] == "R") {
//                AIScore++;
//              } else if (board[i - k][j] == "Y") {
//                pScore++;
//              } else {
//                break;
//              }
//            }
//            
//            if (AIScore == 4) {
//              return 1; 
//            } else if (pScore == 4) {
//              return 2;
//            }
//            
//            AIScore = 0; 
//            pScore = 0;
//          } 
//          
//          //Checking diagonal up-right
//          if(j <= 3 && i >= 3){
//            for(int k = 0; k < 4;k++){
//              if(board[i - k][j + k] == "R") {
//                AIScore++;
//              } else if(board[i - k][j + k] == "Y") {
//                pScore++;
//              } else {
//                break;
//              }
//            }
//            
//            if (AIScore == 4) {
//              return 1; 
//            } else if (pScore==4) {
//              return 2;
//            }
//            
//            AIScore = 0; pScore = 0;
//          }
//          
//          //Checking diagonal up-left
//          if(j >= 3 && i >= 3){
//            for(int k = 0;k < 4;k++){
//              if(board[i - k][j - k] == "R") {
//                AIScore++;
//              } else if(board[i - k][j - k] == "Y") {
//                pScore++;
//              } else {
//                break;
//              }
//            } 
//            
//            if(AIScore == 4) {
//              return 1; 
//            } else if (pScore == 4) {
//              return 2;
//            }
//            
//            AIScore = 0; pScore = 0;
//          }  
//        }
//      }
//      
//      for(int j = 0;j < 7;++j){
//        //Game has not ended yet
//        if(board[0][j] == "O") {
//          return -1;
//        }
//      }
//      //Game draw!
//      return 0; 
//    }
//  }
  
  
  ////////////////////////////////////////*********CHECK VERTICAL FOR MED AI**********\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\     
  public static boolean Check_AI_medium_Vertical(){
    //creates boolean to act as flag
    boolean flag = true;
    
    //creates counter
    int counter = 0;
    
    while(flag) {
      
      //goes through board VERTICTALLY
      for(int height = 0; HEIGHT > height; height ++){
        for(int width = 0; WIDTH > width; width ++){
          
          if(board[height][width] == "R"){ //if it finds an R, add 1 to counter
            counter ++;
          } else {
            counter = 0; // if next piece is not an R, set counter to 0
          }
          
          System.out.print("Counter R (check wins - v) : " + counter);
          
          if(counter == 3){ //checks if there's 3 in a row
            System.out.println("R about to win....");
            board[height + 1][width] = "Y";
            flag = false;
          } else if (counter < 3) { //checks if not 3 in a row
            System.out.println("R not winning....");
            flag = false;
            AIturnSIMPLE2();
            break;
          }
        }
      }
      break;
    }
    return flag;
  }
  
////////////////////////////////////////*********CHECK HORIZONTAL FOR MED AI**********\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\     
  public static boolean Check_AI_medium_Horizontal(){
    //creates boolean to act as flag
    boolean flag = true;
    
    //creates counter
    int counter = 0;
    while(flag){
      
      //goes through board vertically
      for(int height = 0; HEIGHT > height; height += 1){
        for(int width = 0; WIDTH > width; width += 1){
          if(board[height][width] == "R"){ //if it finds an R, add 1 to counter
            counter += 1;
          } else {
            counter = 0; // if next piece is not an Y, set counter to 0
          }
          
          System.out.println("Counter R (check wins - h): " +  counter); //test in console
          
          if (counter == 3) {
            System.out.println("R about to win....");
            board[height][width + 1] = "Y";
            flag = false;
          } else if (counter < 3) {
            System.out.println("R not winning....");
            flag = false;
            AIturnSIMPLE2();
            break;
          }
        }
      }
      break;
    }
    return flag;
  }
  
  ////////////////////////////////////////*********CHECK DIAGONAL FOR MED AI (FORWARD)**********\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\     
  /*public static boolean Check_AI_medium_DiagonalForward(){
   //flag
   boolean flag = true;
   
   //counter
   int counter = 0;
   
   //check boolean
   Boolean check = false;
   
   //checkers
   int checkColumn = 1;
   int checkRow = 1;
   
   while(flag){ //goes through until an Y is found
   for(int height = 0; HEIGHT > height; height += 1){
   for(int width = 0; WIDTH > width; width += 1){
   if(board[height][width] == "Y"){ //if Y is found, add one to counter and go into loop
   counter += 1;
   check = true;
   while(check){ //goes through diagonally looking for Os
   if(checkColumn + height <= HEIGHT - 1&& checkRow + width <= WIDTH - 1){
   if(board[height + checkColumn][width + checkRow] == "Y"){ //if Y is found, add 1 to counter
   counter += 1;
   }
   }
   
   //adds 1 to checkers
   checkColumn += 1;
   checkRow += 1;
   
   if(checkColumn == HEIGHT -1 || checkRow == WIDTH -1){ //if outside of board, break
   check = false;
   break;
   }
   
   if(counter >= 3){
   //System.out.println("Player 2 wins"); //if counter is greater or equal to 4, player wins
   board[height+1][width+1]="R";
   check = false;
   flag = false;
   break;
   }
   }
   }
   if(counter >= 4){
   flag = false;
   break;
   }
   
   //resets counter and checkers
   counter = 0;
   checkColumn = 1;
   checkRow = 1;
   }
   }
   break;
   }
   return flag;
   }
   
   ////////////////////////////////////////*********CHECK DIAGONAL FOR MED AI (BACK)**********\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
   public static boolean Check_AI_medium_DiagonalBack(){
   //flag
   boolean flag = true;
   
   //counter
   int counter = 0;
   
   //check boolean
   Boolean check = false;
   
   //checkers
   int checkColumn = 1;
   int checkRow = 1;
   
   while(flag){
   
   //goes through until an Y is found
   for(int height = 0; HEIGHT > height; height += 1){
   for(int width = 0; WIDTH > width; width += 1){
   if(board[height][width] == "Y"){ //if Y is found, add one to counter and go into loop
   counter += 1;
   check = true;
   while(check){ //goes through diagonally looking for Os
   if(height - checkColumn >= 0 && width - checkRow >= 0){
   if(board[height - checkColumn][width - checkRow] == "Y"){
   counter += 1; //if Y is found, add 1 to counter
   }
   }
   
   //adds 1 to checkers
   checkColumn += 1;
   checkRow += 1;
   
   if(checkColumn == 0 || checkRow == WIDTH -1){ //if outside of board, break
   check = false;
   break;
   }
   
   if(counter >= 3){
   //System.out.println("Player 2 wins"); //if counter is greater or equal to 4, player wins
   board[height+1][width+1]="R";
   check = false;
   flag = false;
   break;
   }
   }
   }
   if(counter >= 4){
   flag = false;
   break;
   }
   
   //resets counter and checkers
   counter = 0;
   checkColumn = 1;
   checkRow = 1;
   }
   }
   break;
   }
   return flag;
   }
   */    
////////////////////////////////////////*********CHECK WINS (RED)**********\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\    
  public static boolean CheckR(){
    //creates flag
    boolean flag = true;
    
    //checks all Rs at once, for clearner main loop
    if(!CheckRVertical() || !CheckRHorizontal()|| !CheckRDiagonalBack()|| !CheckRDiagonalForward()){
      flag = false;
    }
    return flag;
  }
  
////////////////////////////////////////*********CHECK WINS (YELLOW)**********\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\    
  public static boolean CheckY(){
    //creates flag
    boolean flag = true;
    
    //checks all Os at once, for clearner main loop
    if(!CheckYVertical() || !CheckYHorizontal() || !CheckYDiagonalBack() || !CheckYDiagonalForward()){
      flag = false;
    }
    return flag;
  }
}