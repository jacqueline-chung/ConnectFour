//imports
import java.util.Scanner;
import java.util.Random;

public class Connect4AIMinimax { 
  //private Board b;
  static int nextMoveLocation = -1;
  final static int maxDepth = 8;
  
  //global variables
  final static int HEIGHT = 6;
  final static int WIDTH = 7;
  final static int BOTTOM_ROW = HEIGHT - 1;
  static String[][] board = new String[HEIGHT][WIDTH];//game board
  static Scanner userInput = new Scanner(System.in);//scanner 
  
  public static void main(String[] args) {//main method
    //Board b = new Board();
    //Connect4AIMinimax ai = new Connect4AIMinimax();  
    //ai.playAgainstAIConsole();
    
    createBoard(); //create board
    displayBoard(); //display board
    
    System.out.println("Minimax AI");
    
    playAgainstAIConsole(); //ai goes 
    
    System.out.println("You first!");
    letOpponentMove(); //player goes first
    displayBoard(); //display board
    
    System.out.println("AI's turn");
    
    displayBoard(); //display board
  }
  
  ////////////////////////////////////////*********CREATE BOARD**********\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\    
  public static void createBoard() {
    //fills board with "O" for the height and width
    for (int height = 0; HEIGHT > height; height += 1) {
      for (int width = 0; WIDTH > width; width += 1) {
        board[height][width] = "O";
      }
    }
  }
  
////////////////////////////////////////*********DISPLAY BOARD**********\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\     
  public static void displayBoard() {
    //prints the board
    for (int height = 0; height < HEIGHT; height ++) {
      for (int width = 0; width < WIDTH ; width ++) {
        System.out.print(board[height][width]);
      }
      System.out.println();
    }
    System.out.println();
  }
  
  
  //Opponent's turn
  
  
  public static void letOpponentMove(){
    System.out.println("Your move (0-6): ");
    int move = userInput.nextInt();
    
    while(move < 0 || move > 6){
      System.out.println("Invalid move.\n\nYour move (0-6): "); 
      move = userInput.nextInt();
    }
    
    //board[BOTTOM_ROW][move] = "R";
    
    //Assume 2 is the opponent
    placeMove(move, "R"); 
  }
  
  
  
  ////////////////GAME RESUTS FOR MEDIUM AI////////////////
  public static int gameResultsMedium () {
    int AIScore = 0, pScore = 0;
    
    for(int i = 5; i >= 0; i--){
      for(int j = 0; j <= 6; j++){
        
        if(board[i][j] == "O") continue;
        
        //Checking cells to the right
        if (j <= 3){
          for(int k = 0; k < 4; k++){ 
            if(board[i][j+k] == "Y") {
              AIScore++;
            } else if(board[i][j + k] == "R") {
              pScore++;
            } else {
              break; 
            }
            
            if(AIScore == 4){
              return 1; 
            } else if (pScore == 4) {
              return 2;
            }
            AIScore = 0; 
            pScore = 0;
            //return 0;
          } 
          
          //Checking cells up
          if (i >= 3){
            for(int k = 0; k < 4;k++){
              if (board[i - k][j] == "Y") {
                AIScore++;
              } else if (board[i - k][j] == "R") {
                pScore++;
              } else {
                break;
              }
            }
            
            if (AIScore == 4) {
              return 1; 
            } else if (pScore == 4) {
              return 2;
            }
            
            AIScore = 0; 
            pScore = 0;
            //return 0;
          } 
          
          //Checking diagonal up-right
          if(j <= 3 && i >= 3){
            for(int k = 0; k < 4;k++){
              if(board[i - k][j + k] == "Y") {
                AIScore++;
              } else if(board[i - k][j + k] == "R") {
                pScore++;
              } else {
                break;
              }
            }
            
            if (AIScore == 4) {
              return 1; 
            } else if (pScore==4) {
              return 2;
            }
            
            AIScore = 0; 
            pScore = 0;
            //return 0;
          }
          
          //Checking diagonal up-left
          if(j >= 3 && i >= 3){
            for(int k = 0;k < 4;k++){
              if(board[i - k][j - k] == "Y") {
                AIScore++;
              } else if(board[i - k][j - k] == "R") {
                pScore++;
              } else {
                break;
              }
            } 
            
            if(AIScore == 4) {
              return 1; 
            } else if (pScore == 4) {
              return 2;
            }
            
            AIScore = 0; 
            pScore = 0;
            //return 0;
          }  
        }
      }
      
      //Game has not ended yet, no one has won
      for(int j = 0; j < 7; j++){
        //if(board[0][j] == "O" || AIScore == 0 || pScore == 0) {
        if(board[0][j] == "O") {
          return -1;
        }
      }
       
    }
    //Game draw!
      return 0;
  }
  
  public static int calculateScore(int AIScore, int moreMoves){   
    int moveScore = 4 - moreMoves;
    
    if(AIScore == 0) {
      return 0;
    } else if(AIScore == 1) {
      return 1*moveScore;
    } else if(AIScore == 2) {
      return 10*moveScore;
    } else if(AIScore == 3) {
      return 100*moveScore;
    } else {
      return 1000;
    }
  }
  
  //Evaluate board favorableness for AI
  public static int evaluateBoard(){
    //declare variables
    int AIScore = 1;
    int score = 0;
    int blanks = 0;
    int k = 0, moreMoves = 0;
    
    for(int row = 5; row >= 0; row--){
      for(int col = 0; col <= HEIGHT; col++){
        
        if(board[row][col]== "R" || board[row][col] == "Y") continue; 
        
        //check to the right
        if(col <= 3){ 
          for(k = 1; k < 4; k++){
            if(board[row][col + k] == "R"){
              AIScore++;
            } else if (board[row][col + k] == "Y") {
              AIScore = 0;
              blanks = 0;
              break;
            } else {
              blanks++;
            }
          }
          
          moreMoves = 0; 
          
          if(blanks > 0) 
            for(int c = 1; c < 4; c++){
            int column = col + c;
            
            for(int m = row; m <= 5; m++){
              if(board[m][column] == "O") {
                moreMoves++;
              } else {
                break;
              }
            } 
          } 
          
          if(moreMoves!=0) {
            score += calculateScore(AIScore, moreMoves);
            AIScore = 1;   
            blanks = 0;
          }
        } 
        
        //check upward
        if(row >= 3){
          for(k = 1; k < 4; k++){
            if(board[row - k][col] == "Y") {
              AIScore++;
            } else if(board[row - k][col] == "R"){
              AIScore = 0;
              break;
            } 
          } 
          moreMoves = 0; 
          
          if(AIScore > 0){
            int column = col;
            for(int m = (row - k + 1); m <= row - 1; m++){
              if(board[m][column] == "O") {
                moreMoves++;
              } else {
                break;
              }
            }  
          }
          
          if(moreMoves != 0) {
            score += calculateScore(AIScore, moreMoves);
          }
          AIScore=1;  
          blanks = 0;
        }
        
        //checks left
        if(col >= 3){
          for(k = 1; k < 4; k++){
            if(board[row][col - k] == "R") {
              AIScore++;
            } else if(board[row][col - k] == "Y") {
              AIScore=0; 
              blanks=0;
              break;
            }else {
              blanks++;
            }
          }
          moreMoves = 0;
          if(blanks > 0) 
            for(int c = 1; c < 4; c++){
            int column = col - c;
            
            for (int m = row; m <= 5; m++){
              if(board[m][column] == "O") {
                moreMoves++;
              } else {
                break;
              }
            } 
          } 
          
          if(moreMoves!=0) {
            score += calculateScore(AIScore, moreMoves);
          }
          AIScore = 1; 
          blanks = 0;
        }
        
        //check diagonally right and up
        if(col <= 3 && row >= 3){
          for(k = 1; k < 4; k++){
            if(board[row - k][col + k] == "Y") {
              AIScore++;
            } else if(board[row - k][col + k] == "R"){
              AIScore=0;
              blanks=0;
              break;
            } else {
              blanks++;
            }
          }
          
          moreMoves=0;
          
          if(blanks > 0) {
            for(int c = 1; c < 4; c++){
              int column = col + c, r = row - c;
              for(int m = r; m <= 5; m++){
                if(board[m][column] == "O") {
                  moreMoves++;
                } else if(board[m][column] == "R") {
                  ///empty????
                } else {
                  break;
                }
              }
            } 
            if(moreMoves != 0) {
              score += calculateScore(AIScore, moreMoves);
            }
            AIScore=1;
            blanks = 0;
          }
        }
        
        //checks diagonally up and left
        if(row >= 3 && col >= 3){
          for(k = 1; k < 4; k++){
            if(board[row - k][col - k] == "Y") {
              AIScore++;
            } else if(board[row - k][col - k] == "R"){
              AIScore = 0;
              blanks = 0;
              break;
            } else {
              blanks++;
            }
          }
          moreMoves = 0;
          if (blanks > 0){
            for(int c = 1; c < 4; c++){
              int column = col - c, r = row-c;
              for(int m = r; m <= 5; m++){
                if(board[m][column] == "O") {
                  moreMoves++;
                } else if(board[m][column] == "Y") {
                  //empty
                } else {
                  break;
                }
              }
            } 
            if(moreMoves!=0) score += calculateScore(AIScore, moreMoves);
            AIScore=1;
            blanks = 0;
          }
        } 
      }
    }
    return score;
  } 
  
  public static int minimax(int depth, int turn){
    int gameResult = gameResultsMedium();
    
    if(gameResult == 1) {
      return Integer.MAX_VALUE;
    } else if(gameResult == 2) {
      return Integer.MIN_VALUE;
    } else if(gameResult == 0) {
      return 0;
    }
    
    if(depth == maxDepth) {
      return evaluateBoard();
    }
    
    int maxScore=Integer.MIN_VALUE, minScore = Integer.MAX_VALUE;
    
    for(int j = 0; j <= 6; j++){
      //if(!b.isLegalMove(j)) continue;
      
      if(turn == 1){
        placeMove(j, "Y");
        
        int currentScore = minimax(depth + 1, 2);
        maxScore = Math.max(currentScore, maxScore);
        
        if (depth == 0) {
          System.out.println("Score for location "+j+" = "+currentScore);
          if(maxScore == currentScore) {
            nextMoveLocation = j;
          }
        }
        
      } else if(turn == 2) {
        placeMove(j, "R");
        int currentScore = minimax(depth + 1, 1);
        minScore = Math.min(currentScore, minScore);
      }
      undoMove(j);
    }
    return turn==1?maxScore:minScore;
  }
  
  ///////////AI's turn////////////
  public static int getAIMove(){
    nextMoveLocation = -1;
    minimax(0, 1);
    return nextMoveLocation;
  }
  
  ///////////////////////Player's Turn/////////////////////
  public static void playAgainstAIConsole(){
    int humanMove=-1;
    Scanner userInput = new Scanner(System.in);
    System.out.println("Would you like to play first? (y/n) ");
    String answer = userInput.next().trim();
    
    if(answer.equalsIgnoreCase("y")) {
      letOpponentMove();
    }
    
    displayBoard();
    placeMove(3, "Y");
    displayBoard();
    
    while(true){ 
      letOpponentMove();
      displayBoard();
      
      int gameResult = gameResultsMedium();
      if(gameResult == 1){
        System.out.println("AI Wins!");
        break;
      } else if(gameResult == 2){
        System.out.println("You Win!");
        break;
      } else if(gameResult == 0){
        System.out.println("Draw!");
        break;
      }
      
      placeMove(getAIMove(), "Y");
      displayBoard();
      gameResult = gameResultsMedium();
      
      if(gameResult == 1){
        System.out.println("AI Wins!");
        break;
      } else if(gameResult == 2){
        System.out.println("You Win!");
        break;
      } else if(gameResult == 0){
        System.out.println("Draw!");
        break;
      }
    }
  }
  
  //Placing a Move on the board
  public static boolean placeMove(int column, String player){ 
    
    if(column > 6 && column < 0) {
      System.out.println("Illegal move!"); 
      return false;
    }
    
    for(int i = 5;i >= 0; i--){
      if(board[i][column] == "O") {
        board[i][column] = player;
//        if (player == "Y") {
//          board[i][column] = "R";
//        } else if (player == "R") {
//          board[i][column] = "Y";
//        }
        return true;
      }
    }
    return false;
  }
  
  public static void undoMove(int column){
    for(int i = 0; i <= 5; i++){
      if(board[i][column] != "O") {
        board[i][column] = "O";
        break;
      }
    }        
  }
}